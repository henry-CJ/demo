#! /bin/sh
##########uninstall.sh + install.sh

NOW_TIME=`date +%Y%m%d_%H%M%S`
file="$0"
L5_DIR=l5agent-bit64-4.3.0
L5_LINK=l5_agent


################################################
#  get absolute install_path
################################################
get_absolute_path()
{
    if [[ "${file:0:1}" == '/' ]]; then 
        wd=$(dirname "${file}") 
    elif [[ "${file:0:2}" == "./" ]]; then
        wd=$(pwd)/$(dirname "${file}") 
        wd=$(dirname "${wd}") 
    else 
        wd=$(pwd)/$(dirname "${file}") 
    fi

    cd "$wd" || { echo "fail to enter $wd"; exit -1; }
    echo $wd
}

echo -e "\n########################################## upgrading\n"
workdir=$(get_absolute_path)
INSTALL_PATH_PRE=$(dirname "${workdir}")
INSTALL_PATH=${INSTALL_PATH_PRE}/$L5_LINK
INSTALL_PATH_VER=${INSTALL_PATH_PRE}/$L5_DIR
echo uninstall path=$INSTALL_PATH_VER


################################################
#  uninstall "l5_agent"
################################################
cd $INSTALL_PATH_VER && echo cd $INSTALL_PATH_VER
./uninstall.sh
UNINSTALL_SUCC=$?

echo -e "\n\n##############uninstall result=" $UNINSTALL_SUCC "\n\n"

################################################
#  install "l5_agent"
################################################
cd $INSTALL_PATH_VER && echo cd $INSTALL_PATH_VER
./install.sh
INSTALL_SUCC=$?

echo -e "\n\n##############install result=" $INSTALL_SUCC "\n\n"


if [ "$INSTALL_SUCC" -eq 0 ]; then
    echo -e "\n\n########################################## upgrade success\n\n"
else
    echo -e "\n\n########################################## upgrade fail\n\n"
fi
exit $INSTALL_SUCC
