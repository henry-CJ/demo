#!/bin/sh
repMSG=$@
repMSGfile=/tmp/repMSGfile
echo `date +%Y%m%d/%H:%M` $repMSG >> $repMSGfile
#ret=`find $repMSGfile -cmin -5|wc -l`
#if [ $? -ne 0 ];then STR=`tail -n 1 $repMSGfile`;fi
#/usr/local/agenttools/agent/agentRepStr 42084 "$STR"