#!/bin/bash

NOW_TIME=`date +%Y%m%d_%H%M%S`
file="$0"
L5_DIR=l5agent-bit64-4.3.0
L5_LINK=l5_agent

################################################
#  get absolute install_path
################################################
get_absolute_path()
{
    if [[ "${file:0:1}" == '/' ]]; then 
        wd=$(dirname "${file}") 
    elif [[ "${file:0:2}" == "./" ]]; then
        wd=$(pwd)/$(dirname "${file}") 
        wd=$(dirname "${wd}") 
    else 
        wd=$(pwd)/$(dirname "${file}") 
    fi

    cd "$wd" || { echo "fail to enter $wd"; exit 1; }
    echo $wd
}

echo -e "\n########################################## uninstalling\n"
workdir=$(get_absolute_path)
INSTALL_PATH_PRE=$(dirname "${workdir}")
INSTALL_PATH=${INSTALL_PATH_PRE}/$L5_LINK
echo uninstall path=$INSTALL_PATH

################################################
#  delete link name "l5_agent"
################################################
cd $INSTALL_PATH_PRE && echo cd $INSTALL_PATH_PRE
rm $L5_LINK && echo rm $L5_LINK

stop_process()
{
    PRONAME=$1
    echo stoping process "$PRONAME"
    EXIST=0
    while [ 1 ] 
    do
        count=`ps -A|grep -w $PRONAME|grep -v grep|grep -v defunct|wc -l`
        if [ $count -gt 0 ] 
        then    
            killall -9 $PRONAME
            EXIST=1
            sleep 1
        else
            break
        fi  
    done

    if [ $EXIST -eq 0 ] 
    then
        echo $PRONAME not exist!
    else
        echo stop $PRONAME success!
    fi
}

stop_process l5_agent
stop_process dnsagent
stop_process l5_config 
stop_process stat_report

echo -e "\n\n########################################## uninstall success\n\n"
exit 0
