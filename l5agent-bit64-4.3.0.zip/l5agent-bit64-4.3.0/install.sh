#! /bin/sh

NOW_TIME=`date +%Y%m%d_%H%M%S`
file="$0"
L5_DIR=l5agent-bit64-4.3.0
L5_LINK=l5_agent

################################################
#  get absolute install_path
################################################
get_absolute_path()
{
    if [[ "${file:0:1}" == '/' ]]; then 
        wd=$(dirname "${file}") 
    elif [[ "${file:0:2}" == "./" ]]; then
        wd=$(pwd)/$(dirname "${file}") 
        wd=$(dirname "${wd}") 
    else 
        wd=$(pwd)/$(dirname "${file}") 
    fi

    cd "$wd" || { echo "fail to enter $wd"; exit 1; }
    echo $wd
}

workdir=$(get_absolute_path)
INSTALL_PATH_PRE=$(dirname "${workdir}")
INSTALL_PATH=${INSTALL_PATH_PRE}/$L5_LINK
echo INSTALL_PATH=$INSTALL_PATH && echo ""

stop_process()
{
    PRONAME=$1
    echo stoping process "$PRONAME"
    EXIST=0
    while [ 1 ] 
    do
        count=`ps -A|grep -w $PRONAME|grep -v grep|grep -v defunct|wc -l`
        if [ $count -gt 0 ] 
        then    
            killall -9 $PRONAME
            EXIST=1
            sleep 1
        else
            break
        fi  
    done

    if [ $EXIST -eq 0 ] 
    then
        echo $PRONAME not exist!
    else
        echo stop $PRONAME success!
    fi
}

safe_install()
{
    count=`ps -efl | grep "l5_agent" | grep -v grep | wc -l`
    if [ "$count" -gt 0 ]; then
        echo -e "\n########################################## install checking l5_agent\n"
#echo "l5_agent is still running, U could run ./uninstall.sh to stop it first!"
        echo "l5_agent is still running, killing it now!"
        stop_process l5_agent
#exit 2
    fi
    count=`ps -efl | grep "dnsagent" | grep -v grep | wc -l`
    if [ "$count" -gt 0 ]; then
        echo -e "\n########################################## install checking dnsagent\n"
#echo "dnsagent is running, U could run ./uninstall.sh to stop it first!"
        echo "dnsagent is still running, killing it now!"
        stop_process dnsagent
    fi

    count=`ps -efl | grep "l5_config" | grep -v grep | wc -l`
    if [ "$count" -gt 0 ]; then
        echo -e "\n########################################## install checking l5_config\n"
#echo "l5_config is running, U could run ./uninstall.sh to stop it first!"
        echo "l5_config is still running, killing it now!"
        stop_process l5_config 
    fi

#exit 3
    stop_process stat_report
    echo -e "########################################## installing\n"
}


################################################
#  setup link name "l5_agent", then safe_install
################################################
echo -e "########################################## setup link: ln -s $L5_DIR $L5_LINK \n"
cd $INSTALL_PATH_PRE
[[ -f $L5_LINK ]] && mv $L5_LINK l5_agent_bak_$NOW_TIME
safe_install
ln -s $L5_DIR $L5_LINK

################################################
#  setup /data/L5Backup
################################################
USER=`whoami`

if [ ! -d /data/L5Backup ];then
    mkdir -p /data/L5Backup
    if [ $? != 0 ];then
        exit 4
    fi
    chown $USER:users /data/L5Backup
fi
if [ ! -f /data/L5Backup/current_route.backup ];then
    touch /data/L5Backup/current_route.backup
fi

if [ -f /data/L5Backup/apiRouteMap.bin ];then
    cp /data/L5Backup/apiRouteMap.bin $INSTALL_PATH/conf/routetb_info.route
    echo cp /data/L5Backup/apiRouteMap.bin $INSTALL_PATH/conf/routetb_info.route
fi

if [ -f /data/L5Backup/apiRouteMap.weight.bin ];then
    cp /data/L5Backup/apiRouteMap.weight.bin $INSTALL_PATH/conf/routetb_info.weight.route
    echo cp /data/L5Backup/apiRouteMap.weight.bin $INSTALL_PATH/conf/routetb_info.weight.route
fi

chmod ug+x $INSTALL_PATH/bin/* >/dev/null 2>&1
chown $USER:users -R $INSTALL_PATH
	
cd $INSTALL_PATH/lib
[[ ! -f liblbcommon-gcc-4.1.so ]] && ln -s liblbcommon-gcc-4.1.so liblbcommon.so

cd $INSTALL_PATH/conf
chmod +x alarm.sh

################################################
#modify eth 
################################################
ifName=$(ip route show table local | grep local | grep -v eth0|grep -v tun |grep -E ' 10\.|100\.|9\.|172\.' |awk '{print $4}')
if [ "x"$ifName != "x" -a  "x"$ifName = "xeth1" ]; then  
	sed -i s/BindIf=\"eth1\"/BindIf=\"$ifName\"/g $INSTALL_PATH/conf/config.xml 
	sed -i s/BindIf=\"eth1\"/BindIf=\"$ifName\"/g $INSTALL_PATH/conf/stat_report.xml
	sed -i s/BindIf=eth1/BindIf=$ifName/g         $INSTALL_PATH/conf/l5_config.ini
fi

################################################
#if l5server_list is none, and delete 
################################################
SERVER_LIST_FILE=/data/L5Backup/l5server_list.backup
if [ ! -s "$SERVER_LIST_FILE" -a -f "$SERVER_LIST_FILE" ];then
	   mv "$SERVER_LIST_FILE" /tmp
fi

################################################
# safe start
################################################
cd $INSTALL_PATH/bin
./monitor.sh 


################################################
#  add crontab monitor.sh
################################################

add="cd $INSTALL_PATH/bin;./monitor.sh"

echo -e "\n\n####################### crontab begin setup: monitor.sh..."
num=`crontab -l|grep "$add" | grep -v "#" | wc -l`
if [ "$num" -gt 0 ] 
then
    echo "$add had been installed"
    echo -e "\n\n####################### crontab monitor.sh setup success\n\n"
    #exit 0
else
#cron="$(find /var/spool/cron/ -type f -name root)"
    cron=$(mktemp)
    crontab -l > $cron
    echo "* * * * * $add >/dev/null 2>&1" >> $cron
    #echo "* * * * * $add >> /data/l5log" >> $cron
    crontab $cron
    rm $cron
    crontab -l|grep "$add"
fi


################################################
#  add crontab clearfile.sh
################################################

add="cd $INSTALL_PATH/bin;./clearfile.sh"

echo -e "\n\n####################### crontab begin setup: clearfile.sh..."
num=`crontab -l|grep "$add" | grep -v "#" | wc -l`
if [ "$num" -gt 0 ] 
then
    echo "$add had been installed"
    echo -e "\n\n####################### crontab clearfile.sh setup success\n\n"
    #exit 0
else
#cron="$(find /var/spool/cron/ -type f -name root)"
    cron=$(mktemp)
    crontab -l > $cron
    echo "7 5 * * * $add >/dev/null 2>&1" >> $cron
    crontab $cron
    rm $cron
    crontab -l|grep "$add"
fi


################################################

echo "all crontab has been setup success"
echo -e "\n\n########################################## install success\n\n"
exit 0
